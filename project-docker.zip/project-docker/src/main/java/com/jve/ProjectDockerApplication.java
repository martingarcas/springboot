package com.jve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectDockerApplication.class, args);
	}

}
